# Red Menace (v1.6 — *The Grand Victorian Edition*)

**A BepInEx 5 treatise on emergent wilderness survival, domestic pandemonium, and theatrical calamity for *Family Time Episode 3*.**

*Nature is splendidly indifferent, whimsically cruel, and altogether unconcerned with one's afternoon tea.* **Red Menace (v1.6)** transforms tranquil riverbanks, neglected household duties, complacent gaolers, brimming soup bowls, errant house slippers, and unbridled sprinting into a spirited stage of emergent rustic survival — introducing probabilistic river piranha swarms and oceanic Hero Shark rescues with full deep-water Follow pathfinding, crimson-stained streams, dawn neglect fatalities with persistent `X X`-eyed ragdoll remains and consecrated gravestones, a hostage Bamboo Cage with lethal betrayal upon release, a compact Pup Cage animated with frantic bar-rattling hysteria, the towering **Sacrificial Pond** ceremony, the **`MINING`** ore boulder, aerial **Vultures** or newborn-delivering **Storks** (`V`), tusk-impaling **Angry Boars** (`B`) also fit for juvenile cavalry, Olympian **Zeus** strikes (`Z`), on-demand **3-Pup Totem Stacks** (`T`), soup-spilling and playful throwable **La Chancla** athletics (`G` & tool wheel), **Spawn Menu** theatrical props (`O`) featuring bouncing **Cracked Pup Skulls** and rope-bound **Angry Old Men**, cauldron feasts turned suspiciously to poultry, and a trinity of diagnostic salons (`N`, `M`, and `O`) for the discerning director of chaos.

---

## Compendium of Features

### 1. Deep-Water Follow Navigation, River Piranhas (`5%`), Pack Flight, Hero Shark & Blood Water
- **Aquatic Follow Pathfinding Reform:** Pray summon your wards with Follow (`F`) whilst standing waist- or neck-deep amidst the current; charges now march resolutely down riverbanks and paddle straight to your side rather than loitering timidly upon the shingle.
- **The Piranha Wager (`5%`):** Any pup wading (`>= 0.08m`) or swimming casts a sporting **5% die** upon entering the water (and at `30s` intervals thereafter: `AttackRollIntervalSeconds = 30.0`, `AttackRollChance = 0.05`) to summon ravenous **circling piranha swarms** (`MaxPiranhasPerPup = 8`, `TotalMaxPiranhas = 96`, `OrbitSpeed = 5.2 rad/s`, `BiteDamage = 2` HP every `0.70s` after a `0.45s` grace period).
- **Double-Volume Flight & Gallant Ocean Rescues:** When teeth strike, fortunate companions scramble ashore shrieking `SCARED -> PAPA` at **twice customary volume** (`FleeYellVolumeMultiplier = 2.0`), while each unbitten swimmer retains a **5% chance** (`HeroShark.TriggerChance = 0.05`) to cry her complete, unclipped battle-pledge — **`"I WILL SAVE YOU SISTER!"`** — moments before a jaw-snapping **Hero Shark** drags her cleanly into the abyss.
- **Crimson Waters:** Injuries paint expanding **blood slicks** across the surface (`2.6m` initial, `7.2m` maximum radius, `34.0s` dissipation) and imbue submerged vision with an alarming scarlet fog (`UnderwaterTintEnabled = true`).

### 2. Soup Bowl Athletics (`G`) & *La Chancla* Tool Slot
- **The Indignant Soup Flip (`G`):** Whilst bearing a brimming bowl of hot soup, press **`G`** (`BowlSpillKey`) to perform a brisk, fluent procedural wrist-flick — tipping the vessel downward (`~160°`) to empty its contents (`BowlStateController`), scattering broth droplets, staining a fleeting puddle upon the earth with native splash acoustics, and startling all pups within `2.0m` (`STARTLE` / `GRAB_RESIST`) into theatrical dismay.
- **Aerial Bowl Rebukes:** Hurling a soup bowl cleanly into a wandering pup triggers impact burst VFX, startled dismay, and a crestfallen grimace — strictly theatrical, imparting zero injury or knock-out.
- **La Chancla (Custom Tool Slot):** Placed faithfully within your tool wheel **immediately preceding the Mallet** with a crisp hand-crafted diagonal slipper emblem, this upright airborne footwear bounces lively across the turf before resting cleanly for `1.8s`. By strict code of chivalry, **pup bodies already knocked out, slumbering, tumbling, or fallen flat remain wholly intangible** to the slipper's arc, whereas standing charges receive a harmless, spirited pop (`vfxBurstSpawner`, `STARTLE`, cheerful grins, and merry EP3 laughter).

### 3. Compact Iron Pup Containment (`PUP CAGE`, `1` Log)
- **Unlocked from Day One:** Construct the compact **`PUP CAGE`** (`0.56m × 0.56m × 0.78m`, forged cleanly without unsightly pet water-bottles) anywhere upon the turf for **1 Log**.
- **Frantic Bar-Rattling Custody (`E`):** Aim at a nearby pup (`InteractRadius = 3.5m`) and press **`E`**, or drop/toss a carried pup beside the open gate (`1.15m`), to swing the iron door shut behind a brass padlock (`720°/s`). Inside, the detainee keeps her authentic visible nameplate overhead, gazes forth with wide open mournful eyes and chattering mouth, shivers relentlessly, and clutches the front iron bars in articulated procedural panic blasts — synced physically to the rattling cage frame — until released anew with **`E`**. Persists cleanly across saves and Quicksaves.

### 4. Bamboo Cage Hostage (`BAMBOO CAGE`, `1` Log), Retaliation & Cauldron Alchemy
- **The Gaoler's Safeguard (`E` within `3.2m`):** Unlocked from the outset for **1 Log**. Present **Wolf Mama** (carried or standing beside the structure) and press **`E`** to bolt her permanently indoors in `standing_scare` with blazing red eyes — halting dawn rage points, punishment dreams, and premature Game Over scenes whilst imprisoned.
- **The Gaoler's Reckoning:** Should even a single pup perish beneath your roof while Wolf Mama fumes behind bamboo bars, **unlocking that gate with `E` unleashes her lethal ambush upon the spot**. Cages, ponds, and retaliation flags endure reliably across both normal saves and Quicksaves.
- **Autonomous Wolf Mama Mourning & Cauldron Cookery (New in v1.6):**
  - **Player Deposit:** Dropping, tossing, or aiming **`E`** with a pup corpse into any lit, water-filled cauldron lacking meat converts the remains forthwith into **+100 wholesome chicken drumsticks** (with `CauldronLogicManager.IsValidIngredientState` harmony integration).
  - **Wolf Mama's Bewildered Lament:** Should uncaged Wolf Mama spy a settled corpse within `10m` (`>= 1.8s` settled), she stalks thoughtfully over, lifts the child gently into her arms, rocks and cradles her for a full **60 seconds** with bewildered spiral eyes and native EP3 laments (`woah` / tender vocalizations), and finally marches to the nearest lit meatless cauldron to commit the offering for **100 drumsticks**.

### 5. Towering `SACRIFICIAL POND` Ceremony (`1` Log) & Restored `MINING` Boulder (`1` Boulder)
- **`SACRIFICIAL POND` (`1` Log):** Unlocked from the beginning, raising a piranha-filled basin beneath a `3.55m` diving ladder and springboard (`[E] Sacrifice a Pup to the Piranha GOD`) ringed with perimeter pathfinding blockers so pups stroll cleanly around the stonework. Pressing **`E`** dubs **`THE CHOSEN ONE`**, calls up to **100** spectators chanting `want 2` until **70%** assemble, dispatches the diver upward (`hop` -> guaranteed 100% piranha frenzy with zero Hero Shark interruption -> **Chicken Drumstick sky rain**), and leaves a fearless pup-haired Skeleton tossed merrily in rotation by **2** acolytes until any **`E`** or **`F`** command dismisses the gathering.
- **`MINING` Ore Boulder (`1` Boulder):** Unlocked from day one (`[Mining]`). Assign up to **4** industrious workers via **`E`** outfitted in illuminated miner helmets and pickaxes to strike sparks and metallic chimes every `1.25s`.

### 6. Sky, Beast & Olympian Hotkeys: Vulture / Stork (`V`), Angry Boar (`B`) & Zeus (`Z`)
Upon entering play, gilded banners announce your active prerogatives for ten seconds:
- **`V` — Vulture or Gentle Stork:** By default (`UseStorkMode = false`), summons an articulated carrion **Vulture** that stoops from the clouds to carry off a pup (`68.0m` despawn). Toggle **`[V] stork`** inside the **`M`** panel (or set `UseStorkMode = true`) to summon instead an elegant black-and-white **Stork** bearing a knotted cloth bundle in her crimson beak — gliding low to deposit a freshly minted native pup upon the meadow with joyful giggles before soaring homeward!
- **`B` — Angry Boar (`MaxHealth = 12`):** Summons a furious tusker that impales a random pup alive upon its left ivory tusk until slain (airborne pup collisions inflict `0` damage to pups and **1 HP** to the Boar).
- **`Z` — Zeus Intervention:** Calls celestial judgment upon a random pup without incurring Wolf Mama's wrath. Choose inside **`M`** between **`[Z] lightning bolt`** (jagged sky-bolt + thunderclap) and **`[Z] heavenly wrath`** (sacred golden pillar + celestial chime).

### 7. Boar Cavalry, Canine Zoomies, Non-Lethal Pup Fire & On-Demand Totems (`T`)
- **On-Demand 3-Pup Totem Stacks (`T`):** Group all idle charges into wobbly three-tier vertical towers (50/50 `mama` / `papa` chorus) that obey **`F`** Follow/GoTo/Stop through the base pup while declining **`E`** labour; press **`T`** anew for a polite two-step dismount.
- **Boar Rider Cavalry (`M` -> `boar rider`):** Mounts targeted (or all) pups atop genuine wild EP3 boars (`80%` upright `SIT` saddle posture, `20%` comic peek), ignoring **`E`** work whilst faithfully obeying **`F`** Follow/GoTo marches amid merry `wahoo` / `wee` / `giggle` cheers (`cure & feed` dismounts cleanly).
- **Zoomies Modes (`M` -> `zoomies light` / `zoomies plus`):**
  - **`zoomies light`:** Lively bounding sprints with native AI, `E`/`F` obedience, `WANT`/`STARTLE` bursts, and zero collisions left completely intact.
  - **`zoomies plus`:** Persistent manic circuit-running and playful bush-hiding strictly within `6m` of stationary Father with gentle nudges and VFX bursts, yielding dutifully the instant you stride away or issue **`E`**.
- **Theatrical Pup Fire (`M` -> `set on fire` or Lit Cauldrons/Hearths):** Ignites crackling procedural flames and rising smoke for 10-second panic sprints (`50%` bump spread), transitioning at `120s` into a **strictly non-lethal** smoky `Dying` crawl toward the nearest river (`WaterSurfaceSampler`) — never killing the pup and never arousing Wolf Mama, yet remaining grabbable/pettable until doused by water or `cure & feed`.

### 8. Mortal Neglect (`BeginNewDay`), Permanent `X X` Corpses & Gravestones
- Existing pups left genuinely unfed or unwatered until sunrise perish cleanly (`NeglectDeathEnabled = true`; overnight newborns are faithfully spared on their first dawn), settling as permanent physics-reactive ragdoll remains with closed lids and 3D black **`X X`** eyes (`5.0m` mourning `CRY` radius).
- Aim at solid earth whilst bearing a corpse (`LMB`) or direct pup bearers (`E`) to inter the fallen beneath a wooden **gravestone**.

### 9. Grand Control Salons: Studio (`N`), State (`M`), Spawn Menu (`O`) & Sprint Dodge Reform
- **Studio Panel (`N`) — Now with `wolf mama` Mode:** Direct pup animations, loops, facial expressions, native voice clips (`sounds (<count>)`), and the persistent `9:16` YouTube Shorts reticle — **now featuring a dedicated `wolf mama` toggle** granting full command over Wolf Mama's **`anims | eyes | mouth | pupils | voice`** repertoire on demand.
- **State Salon (`M`):** Trigger **`hungry`**, **`thirsty`**, greenish **`sick (vomit)`**, **`dead (corpse)`**, **`set on fire`**, **`boar rider`**, **`zoomies light`**, **`zoomies plus`**, **`starvation (global)`** (hungry-only **Evening** auto-trigger with `3.5m` Runt bush lead, `~25%` Runt flee pace, pup-haired Skeleton feast, and `25%` lingering red cannibal eyes), **`rebellion`** (3-pup cage-breaking mutiny), **`[Z]` mode**, **`[V] vulture / stork`**, and **`cure & feed`**.
- **Spawn Menu (`O`, `SpawnMenu.PanelKey = O` — Strictly `actors` & `tools`):**
  - **Tab `actors` — The Bound Villager (`Angry Old Man`):** Spawns a rope-bound, boot-kicking, jaw-shouting grumpy villager (`CaptiveOldManManager`) sporting either an articulated procedural 3D rig or your custom `BepInEx\plugins\RedMenace\Assets\angry_old_man.glb` / `.obj` mesh (hot-reloadable in-game!). Grabbable by hand or **carried simultaneously by 4 pups via `[E]`** (`CommandShape.TWO_BY_TWO`), complete with gravelly muffled grumbles.
  - **Tab `tools` — Cracked Pup Skull Soccer:** Drops bouncing, fractured wolf-pup skulls (`with bone gibs` or `clean`) that immediately beckon **2 playful pups** (or any two pups upon pressing **`E`** while aiming at a skull) to dribble and pass endlessly back and forth with `THROW`/`ATTACK` kicks, giggles, and cheerful expressions.
- **0% Sprint Knockback Dodge (`Left Shift`) vs. 90% Jog Dodge:** Running normally among pups rolls a gentlemanly **90% dodge** (`DodgeChance = 0.90`); **full-speed sprinting lowers dodge odds to a crisp `0%`**, sending pups tumbling cleanly with boar-style physics (`vfxBurstSpawner`, `IN_AIR_FALL`, zero damage).

### 10. Concerning Certain Salacious Village Rumours
- Pay no heed whatever to breathless whispers circulating round the village well regarding an alleged cast-iron "Meat Grinder" contraption. Upon the solemn honour of a Victorian gentleman, this author declares all such culinary gossip to be pure moonshine, fiddle-faddle, and an impudent scoundrel's jest!

---

## Requirements

- **Family Time Episode 3** (Windows x64 DX11 / Mono)
- **BepInEx 5** (`BepInEx 5.4.23.5` or compatible BepInEx 5.x for Unity Mono; `0Harmony.dll` included)

---

## Save Compatibility & Custom External Assets

- All custom blueprints (`BAMBOO CAGE`, `PUP CAGE`, `SACRIFICIAL POND`, `MINING`), caged occupants, cage retaliation flags, gravestones, and ragdoll corpses persist cleanly across standard saves and Quicksaves inside an adjacent `<SaveFile>.family.redmenace.dat` sidecar file, leaving vanilla `.family` save files untouched.
- **Optional External 3D Meshes (`.glb` / `.obj`):** Place custom `angry_old_man.glb` or `angry_old_man.obj` files (plus optional sibling textures) into `<GameDir>\DX11\BepInEx\plugins\RedMenace\Assets\` and click **`reload .glb/.obj assets`** inside the **`[O]` Spawn Menu** without restarting the game.

---

## Installation

1. Verify **BepInEx 5** (Mono x64) is installed in your *Family Time Episode 3* `DX11` folder (`FamilyTime.exe` directory).
2. Extract **`RedMenace-v1.6.0.zip`** directly into your `DX11` folder (overwriting any previous DLL) so that the plugin lands at:
   ```text
   <GameDir>\DX11\BepInEx\plugins\RedMenace\RedMenace.dll
   ```
3. Launch the game once. BepInEx will generate or migrate your configuration file at:
   ```text
   <GameDir>\DX11\BepInEx\config\com.redmenace.hazards.cfg
   ```

To uninstall, simply delete `BepInEx\plugins\RedMenace\RedMenace.dll` (and optionally `BepInEx\config\com.redmenace.hazards.cfg`).

---

## Configuration (`com.redmenace.hazards.cfg`)

- `[Piranha]` — `Enabled`, `MaxPiranhasPerPup` (`8`), `TotalMaxPiranhas` (`96`), `Scale` (`1.0`), `OrbitRadius` (`1.15`), `OrbitSpeed` (`5.2`), `BiteDamage` (`2`), `BiteCooldownSeconds` (`0.70`), `SwimGraceSeconds` (`0.45`), `CanDamagePlayer` (`false`), `AttackRollIntervalSeconds` (`30.0`), `AttackRollChance` (`0.05`), `FleeYellVolumeMultiplier` (`2.0`)
- `[HeroShark]` — `Enabled` (`true`), `TriggerChance` (`0.05`)
- `[BloodWater]` — `Enabled` (`true`), `InitialRadius` (`2.6`), `MaxRadius` (`7.2`), `FadeDurationSeconds` (`34.0`), `UnderwaterTintEnabled` (`true`)
- `[PanicBehavior]` — `Enabled` (`true`), `HungryCarrySeconds` (`10.0`), `PiranhaProximityRadius` (`14.0`)
- `[WolfMamaWrath]` — `Enabled` (`true`), `TeleportDistance` (`2.8`), `FovDetectionMaxDistance` (`24.0`), `GroundGameOverDelaySeconds` (`0.2`)
- `[BambooCage]` — `Enabled` (`true`), `InteractRadius` (`3.2`)
- `[PupCage]` — `Enabled` (`true`), `InteractRadius` (`3.5`)
- `[SacrificialPond]` — `Enabled` (`true`)
- `[Mining]` — `Enabled` (`true`), `HitIntervalSeconds` (`1.25`)
- `[Vulture]` — `Enabled` (`true`), `SpawnKey` (`V`), `CarryRemoveDistance` (`68.0`), `UseStorkMode` (`false`)
- `[AngryBoar]` — `Enabled` (`true`), `SpawnKey` (`B`), `MaxHealth` (`12`)
- `[ZeusLightning]` — `Enabled` (`true`), `StrikeKey` (`Z`), `UseHeavenlyWrath` (`false`)
- `[TotemStack]` — `Enabled` (`true`), `ToggleKey` (`T`)
- `[BowlInteraction]` — `SpillKey` (`G`)
- `[Chancla]` — `Enabled` (`true`)
- `[Starvation]` — `Enabled` (`true`), `RuntCheckIntervalSeconds` (`30.0`), `RuntChance` (`0.02`), `MaxFeeders` (`4`)
- `[NeglectDeath]` — `Enabled` (`true`), `CorpseCryRadius` (`5.0`)
- `[PupAnimationPanel]` — `PanelKey` (`N`), `MaxPickDistance` (`16.0`)
- `[PupStatePanel]` — `PanelKey` (`M`), `MaxPickDistance` (`16.0`)
- `[SpawnMenu]` — `PanelKey` (`O`)
- `[DadKnockback]` — `Enabled` (`true`), `MinSpeed` (`2.3`), `HorizForce` (`5.5`), `UpForce` (`5.0`), `HitRadius` (`1.1`), `CooldownSeconds` (`0.85`), `DodgeChance` (`0.90`; forced `0%` while sprinting)
- `[Internal]` — `SchemaVersion` (`2`)

---

## Philosophy, License & Legal Disclaimer

- **Design Philosophy:** *Red Menace* is crafted around **emergent wilderness survival** and theatrical sandbox comedy rather than real-world harm.
- **Open Source & Free Forever:** Published under the **MIT License** (see `LICENSE`). All features are completely free with no subscriptions or paywalls.
- **Fictional Disclaimer:** All wildlife perils, crimson streams, skeletal props, and slapstick disasters transpire strictly inside a stylized fictional game world. Always back up save files prior to installing gameplay modifications. Not affiliated with or endorsed by the original developers of *Family Time*.
