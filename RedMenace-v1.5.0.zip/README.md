# Red Menace (v1.5)

**A BepInEx 5 gameplay & hazard mod for *Family Time Episode 3*.**

*Nature is cruel, unpredictable, and indifferent.* Red Menace turns calm rivers, neglected chores, complacent jailers, and reckless sprinting into emergent wilderness survival — adding probabilistic piranha attacks and hero-shark ambushes with full deep-water Follow swimming, bloodied water, dawn neglect fatalities with permanent `X X`-eyed ragdoll corpses & burial gravestones, a persistent bamboo hostage cage (with lethal retaliation if reopened after a pup death), a tall **Sacrificial Pond** ceremony (`THE CHOSEN ONE`), the **`MINING`** boulder blueprint, sky-snatching **Vultures** (`V`), charging **Angry Boars** (`B`), **Zeus / Heavenly Wrath** strikes (`Z`), on-demand **3-Pup Totem Stacks** (`T`), hungry-only **Evening Starvation** & 3-pup **Rebellion** events (`M`), and an animation & sounds control panel (`N`).

---

## Features

### 1. Deep-Water Follow Swimming, River Piranhas (`5%`), Pack Flight, Hero Shark & Blood Water
- **Water Follow Pathfinding Fix:** Commanding Follow (`F`) while standing or swimming in deep water now routes pups cleanly off riverbanks and shorelines to swim right out to you instead of stopping at the edge.
- Pups wading (`>= 0.08m`) or swimming in water roll a **5% chance** on water entry (and every `30s` thereafter, `AttackRollIntervalSeconds = 30.0`, `AttackRollChance = 0.05`) to attract aggressive **circling piranha swarms** (`MaxPiranhasPerPup = 8`, `TotalMaxPiranhas = 96`, `OrbitSpeed = 5.2 rad/s`, `BiteDamage = 2` HP every `0.70s`).
- During a piranha attack, unattacked pups flee ashore screaming `SCARED` -> `PAPA` at **double volume** (`FleeYellVolumeMultiplier = 2.0`), and each unattacked pup has a **5% chance** (`HeroShark.TriggerChance = 0.05`) to cry **`"I WILL SAVE YOU SISTER!"`** right before a jaw-snapping **Hero Shark** drags her down into the depths (audio plays out cleanly without cutoff even on pup death).
- Injuries spread **crimson blood slicks** (`2.6m` initial, `7.2m` max radius, `34.0s` fade) and tint underwater fog red (`UnderwaterTintEnabled`).

### 2. Bamboo Cage Hostage (`BAMBOO CAGE`), Retaliation & Save Persistence
- Unlocked from the start (**`BAMBOO CAGE`**, costs **1 Log**). Bring **Wolf Mama** within `InteractRadius = 3.2m` (carried or standing nearby) and press **`E`** to lock her inside permanently in `standing_scare` with glowing red eyes, blocking rage points, sleep punishment movies, and Game Over triggers while imprisoned.
- **Cage Retaliation:** If any pup dies while Wolf Mama is imprisoned in the cage, **reopening the cage with `E` immediately unleashes Wolf Mama to kill the player**. Placed cages, ponds, and death retaliation state persist cleanly across normal saves and **Quicksaves**.

### 3. `SACRIFICIAL POND` Blueprint (`1` Log)
- Unlocked from the start (costs **1 Log**). Places a piranha-infested basin beneath a tall (`3.55m`) diving ladder and springboard (`[E] Sacrifice a Pup to the Piranha GOD`), with full perimeter nav blockers so wandering and following pups route smoothly around the pond walls and tower.
- Aim and press **`E`** to dub a pup **`THE CHOSEN ONE`**, summoning up to **100** pups into a semicircle looping `want 2`. Once **70%** of spectators are in place, THE CHOSEN ONE climbs the ladder, leaps with `hop` audio into a 100% piranha frenzy (without panic, Hero Shark, or distracting status overlays), triggers a **Chicken Drumstick sky rain**, and leaves an authentic pup-haired no-fear skeleton tossed in a loop by **2** pups while spectators hold `want 2` until you issue any **`E`** or **`F`** command.

### 4. `MINING` Blueprint (`1` Boulder)
- Re-enabled and unlocked from the start (`[Mining]` config section). Assign up to **4** pups with **`E`** to equip glowing miner helmets and pickaxes, chipping away at the ore boulder with anime swing arcs, metallic strikes, and flying sparks (`HitIntervalSeconds = 1.25`).

### 5. Sky, Beast & Divine Hotkey Hazards: Vulture (`V`), Angry Boar (`B`) & Zeus (`Z`)
- Loading into gameplay displays `"PRESS [V] to call a Vulture"`, `"PRESS [B] to summon an Angry Boar"`, and `"Press [Z] to call Zeus intervention"` for 10 seconds:
  - **`V` (Vulture):** Summons a circling vulture that swoops down, grabs a pup in its talons, and carries it off into the sky.
  - **`B` (Angry Boar):** Summons an Angry Boar (`BoarMaxHealth = 12`) that impales a random pup alive on its left tusk; the pup can be freed only by slaying the Boar (every pup launched airborne deals `0` pup damage and **1 HP** damage to the Boar).
  - **`Z` (Zeus Intervention):** Strikes a random living pup from above, leaving an overcooked smoking corpse **without triggering Wolf Mama's wrath**. Toggle in the **`M`** panel between **`[Z] lightning bolt`** (jagged bolt + thunder that startles nearby pups) and **`[Z] heavenly wrath`** (golden beam of sacred light + celestial sound).

### 6. On-Demand 3-Pup Totem Stacks (`T`)
- Press **`T`** to group all unoccupied living pups into wobbly 3-tier vertical totems with a 50% `mama` / 50% `papa` vocal roll.
- Stacked trios follow **`F`** commands (Follow / GoTo / Stop) via the bottom pup while **`E`** work commands remain blocked. Press **`T`** again for an animated 2-step dismount (top 3rd climbs down first, then 2nd).

### 7. Neglect Deaths, Permanent `X X` Corpses & Burial Gravestones
- At dawn (`BeginNewDay`), existing pups left hungry or thirsty from the previous day die from neglect (`NeglectDeathEnabled = true`), leaving permanent physics-settled ragdoll corpses with 3D black **`X X`** eyes (`5.0m` mourning `CRY` radius for nearby pups).
- Aiming at ground while carrying a corpse (`LMB`) or commanding pup-carried corpses (`E`) buries the pup beneath a persistent wooden **gravestone**.

### 8. Pup State Control Panel (`M`) — Hunger, Sickness, Evening Starvation & Rebellion
- Press **`M`** (aimed at a pup or toggling all pups) to trigger **`hungry`**, **`thirsty`**, **`sick (vomit)`**, **`dead (corpse)`**, **`starvation (global)`**, **`rebellion`**, or switch **`[Z]`** between **`lightning bolt`** and **`heavenly wrath`**:
  - **Starvation Overhaul:** Affects **hungry pups only** (both victim and attackers) and **triggers automatically when `Evening` arrives** (or `2% / 30s` passively while Wolf Mama is caged, suppressed during Rebellion). The **`RUNT`** flees into the nearest bush; hungry sisters chase once a **`3.5m`** lead opens while the Runt slows to **~25%** speed; up to **4** sisters feast (`EAT`) leaving a pup-haired Skeleton, keep feeding in a continuous chain until all hungry pups are fed, and have a **25%** chance to keep aggressive red eyes and open jaws for the rest of the day.
  - **`rebellion`:** Stacks **3** pups into a swaying vertical totem shouting `mama` at `3x` volume while marching to unlock Wolf Mama's Bamboo Cage.

### 9. Pup Animation & Sounds Control Panel (`N`) & 90% Dad Dodge Roll
- Press **`N`** to open the animation/audio studio overlay (`this pup` / `all pups` / `pick again`, `all` / `actions` / `movement` / `sounds (<count>)`, `loop: ON/OFF`, persistent `yt shorts 9:16` framing lines, `reset idle`).
- Running/sprinting through pups performs a **90% RPG dodge roll** (`DodgeChance = 0.90`): 90% nimble step-back, 10% boar-style physics tumble with zero damage.

### 10. Concerning Preposterous Rumours
- Pay no mind to idle whispers in the village concerning an alleged "Meat Grinder" apparatus: I assure you upon the honour of a Victorian gentleman that such lurid gossip is sheer moonshine and tomfoolery.

---

## Requirements

- **Family Time Episode 3** (Windows DX11 / Mono)
- **BepInEx 5** (`BepInEx 5.4.23.5` or compatible BepInEx 5.x for Unity Mono)

---

## Save Compatibility

- All custom blueprints, caged Wolf Mama / retaliation flags, gravestones, and permanent pup corpses are stored cleanly in an adjacent `<SaveFile>.family.redmenace.dat` sidecar file and survive both standard saves and Quicksaves. Base `.family` save files remain vanilla-compatible.

---

## Installation

1. Install **BepInEx 5** into your game's `DX11` folder (`FamilyTime.exe` directory) if not already installed.
2. Extract the contents of `RedMenace-v1.5.0.zip` into the `DX11` folder so that the DLL lands at:
   ```text
   <GameDir>\DX11\BepInEx\plugins\RedMenace\RedMenace.dll
   ```
3. Launch the game once. BepInEx will automatically generate (or migrate) your config at:
   ```text
   <GameDir>\DX11\BepInEx\config\com.redmenace.hazards.cfg
   ```

To uninstall, simply delete `BepInEx\plugins\RedMenace\RedMenace.dll` (and optionally `BepInEx\config\com.redmenace.hazards.cfg`).

---

## Configuration (`com.redmenace.hazards.cfg`)

- `[Piranha]` — `Enabled`, `MaxPiranhasPerPup` (`8`), `TotalMaxPiranhas` (`96`), `Scale` (`1.0`), `OrbitRadius` (`1.15`), `OrbitSpeed` (`5.2`), `BiteDamage` (`2`), `BiteCooldownSeconds` (`0.70`), `SwimGraceSeconds` (`0.45`), `CanDamagePlayer` (`false`), `AttackRollIntervalSeconds` (`30.0`), `AttackRollChance` (`0.05`), `FleeYellVolumeMultiplier` (`2.0`)
- `[HeroShark]` — `Enabled` (`true`), `TriggerChance` (`0.05`)
- `[BloodWater]` — `Enabled` (`true`), `InitialRadius` (`2.6`), `MaxRadius` (`7.2`), `FadeDurationSeconds` (`34.0`), `UnderwaterTintEnabled` (`true`)
- `[PanicBehavior]` — `Enabled` (`true`), `HungryCarrySeconds` (`10.0`), `PiranhaProximityRadius` (`14.0`)
- `[WolfMamaWrath]` — `Enabled` (`true`), `TeleportDistance` (`2.8`), `FovDetectionMaxDistance` (`24.0`), `GroundGameOverDelaySeconds` (`0.2`)
- `[BambooCage]` — `Enabled` (`true`), `InteractRadius` (`3.2`)
- `[SacrificialPond]` — `Enabled` (`true`)
- `[Mining]` — `Enabled` (`true`), `HitIntervalSeconds` (`1.25`)
- `[Vulture]` — `Enabled` (`true`), `SpawnKey` (`V`), `CarryRemoveDistance` (`68.0`)
- `[AngryBoar]` — `Enabled` (`true`), `SpawnKey` (`B`), `MaxHealth` (`12`)
- `[ZeusLightning]` — `Enabled` (`true`), `StrikeKey` (`Z`), `UseHeavenlyWrath` (`false`)
- `[TotemStack]` — `Enabled` (`true`), `ToggleKey` (`T`)
- `[Starvation]` — `Enabled` (`true`), `RuntCheckIntervalSeconds` (`30.0`), `RuntChance` (`0.02`), `MaxFeeders` (`4`)
- `[NeglectDeath]` — `Enabled` (`true`), `CorpseCryRadius` (`5.0`)
- `[PupAnimationPanel]` — `PanelKey` (`N`), `MaxPickDistance` (`16.0`)
- `[PupStatePanel]` — `PanelKey` (`M`), `MaxPickDistance` (`16.0`)
- `[DadKnockback]` — `Enabled` (`true`), `MinSpeed` (`2.3`), `HorizForce` (`5.5`), `UpForce` (`5.0`), `HitRadius` (`1.1`), `CooldownSeconds` (`0.85`), `DodgeChance` (`0.90`)
- `[Internal]` — `SchemaVersion` (`2`)

---

## Philosophy, Donations & Legal Disclaimer

- **Artistic & Design Philosophy:** Red Menace is designed around **emergent wilderness survival** and theatrical sandbox chaos rather than real-world cruelty.
- **Open Source & Free Forever:** Source code is provided under the **MIT License** (see `LICENSE`). All features of this mod are 100% free with **no subscriptions, no paywalls, and no recurring tiers**.
- **Fictional Game Mod Disclaimer:** All depictions of wildlife, blood water visuals, and peril take place strictly within a stylized fictional video-game environment. This project does not promote or condone real-world harm to animals. Use is at your own discretion; back up save files before installing gameplay mods. Not affiliated with or endorsed by the original developers of *Family Time*.
