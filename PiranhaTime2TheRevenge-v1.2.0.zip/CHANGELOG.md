# Changelog — Piranha Time 2: The Revenge

## v1.2 (1.2.0) — *The Grand Victorian Edition*
- **Compact Iron Pup Cage (`PUP CAGE` — No Water Feeder) & Rewritten Simpsons-Style Panic Animation:**
  - Added the craftable **`PUP CAGE`** blueprint (`1` Log) and `PupCageManager` (lock/release via **`[E]`** or carry-drop near the open gate, full save/Quicksave persistence, and `PupWaterTracker` exclusion).
  - Completely rewrote the procedural panic animation from verified neutral bone axes and cached rest poses in `LateUpdate()` with a `0.15s` SmoothStep entry blend: zero frame-0 snap or ear/ceiling clipping (`0.78m` cage height + `FitScale`), tightly tucked floor crouch pressed near the front bars, shrugged shoulders, level/upward outward gaze with nervous darting glances, wide mournful eyes + chattering `mouth_e`, hands anchored directly onto `LeftBarGripAnchor`/`RightBarGripAnchor` with curled fingers, and continuous `14–18 Hz` shiver plus periodic frantic bar-rattling bursts synced to cage visual rattle.
  - Restored live overhead **pup nameplates** above occupied cages via `FakeGATManager.TryGetPosition` and `GATNames.AddActiveName`.
- **Soup-Bowl Flip Animation (`[G]`) & 0% Sprint Knockback Dodge:**
  - Added a fluent upside-down pouring animation (`Flip-In -> Splash/Empty -> Hold -> Return`) when pressing **`[G]`** with a soup-filled bowl.
  - Lowered pup dodge probability to **`0%`** whenever Dad holds `Left Shift` / sprints through pups (`DadKnockbackManager`), sending every pup in his path tumbling cleanly.
- **La Chancla Tool Refinements:**
  - Adjusted the held 3D Chancla grip so it is held upright from the heel base matching its diagonal UI icon, suppressed false `WorldSerializer.ReportRecovery` load popups, and made pups knocked down / rising from the ground completely **intangible** to thrown slippers until they stand back up.
- **Grand Victorian Documentation:** Updated `README.md`, `README.txt`, `CHANGELOG.md`, and `NEXUSMODS_PAGE.md` for `v1.2.0`.

## v1.1 (1.1.0)
- **Ported Full Hazard & Survival Suite to *Family Time Episode 4*:**
  - Deep-water Follow (`F`) pathfinding fix (`NavWaterFollowPatch`), 5% river piranha swarms, 5% unclipped Hero Shark (`"I WILL SAVE YOU SISTER!"`), blood slicks & red underwater fog tint.
  - Dawn neglect fatalities (`X X`-eyed ragdoll corpses & burial gravestones), persistent **Bamboo Cage** hostage & retaliation, **`SACRIFICIAL POND`** (`THE CHOSEN ONE` + drumstick rain), **`MINING`** boulder, **Vulture** (`V`), **Angry Boar** (`B`), **Zeus / Heavenly Wrath** (`Z`), **3-Pup Totem Stacks** (`T`), hungry-only **Evening Starvation Runt** & **Rebellion** (`M`), and **90% Dad Dodge Roll**.
- **Campfire Fire-Panic, 60s Dying Crawl & Water Cure (`PupFireManager`)** & **Wolf Mama Spiral-Eyed Corpse Cauldron Ritual (`WolfMamaCorpseCauldronManager`)**.
- **Episode 4 Studio (`N`), State Panel (`M`), Animal Chatter (`AnimalChatterManager`) & 1-Grass Hairbrush Unlock (`HairstyleService`)**.
- **Boulder Trap & `[Z] boulder` Crushing**, **`[O]` Spawn Menu (`Actors` / `Books` / `Tools` w/ Angry Old Man & Cracked Skull Soccer)**, **`[G]` Bowl Mischief**, and **La Chancla** tool slot.
