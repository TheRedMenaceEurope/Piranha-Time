# Piranha Time 2: The Revenge (v1.2 — *The Grand Victorian Edition*)

**A BepInEx 5 treatise on emergent wilderness peril, domestic pandemonium, and theatrical calamity for *Family Time Episode 4*.**

*Nature is splendidly indifferent, whimsically cruel, and altogether unconcerned with one's afternoon tea.* **Piranha Time 2: The Revenge (v1.2)** (`RedMenaceRevenge.dll`) bestows upon tranquil riverbanks, crackling campfires, neglected evening duties, complacent gaolers, brimming soup bowls, errant house slippers, and unbridled sprinting a spirited stage of emergent rustic theatre — uniting deep-water Follow swimming, 5% river piranha swarms and Hero Shark rescues, crimson-stained streams, dawn neglect fatalities with `X X`-eyed ragdoll remains and consecrated gravestones, a persistent hostage **Bamboo Cage** with lethal betrayal upon release, a compact waterless **Pup Cage** animated with frantic bar-rattling hysteria and live overhead nameplates, the towering **Sacrificial Pond** (`THE CHOSEN ONE`), the **`MINING`** ore boulder, aerial **Vultures** or newborn-delivering **Storks** (`V`), tusk-impaling **Angry Boars** (`B`) also fit for juvenile cavalry, Olympian **Zeus** strikes and boulder traps (`Z`), on-demand **3-Pup Totem Stacks** (`T`), soup-flipping (`G`) and upright throwable **La Chancla** athletics (with chivalrous ground-pup intangibility), **Campfire Ignition -> 60s Dying Crawl -> Water Healing**, **Wolf Mama's Spiral-Eyed Cauldron Ritual (100 Chicken Drumsticks)**, boosted **Animal Chatter**, **1-Grass Hairbrush + All Hairstyles Unlocked**, and a trinity of diagnostic salons (**`N`**, **`M`**, and **`O`**) for the discerning director of chaos.

---

## Compendium of Features

### 1. Deep-Water Follow Navigation, River Piranhas (`5%`), Pack Flight, Hero Shark & Blood Water
- **Aquatic Follow Pathfinding Reform:** Pray summon your wards with Follow (`F`) whilst standing waist- or neck-deep amidst the current; charges now march resolutely down riverbanks and paddle straight to your side rather than loitering timidly upon the shingle.
- **The Piranha Wager (`5%`):** Any pup wading (`>= 0.08m`) or swimming casts a sporting **5% die** upon entering natural water (and every `30s` thereafter: `AttackRollIntervalSeconds = 30.0`, `AttackRollChance = 0.05`) to summon ravenous **circling piranha swarms** (`MaxPiranhasPerPup = 8`, `TotalMaxPiranhas = 96`, `OrbitSpeed = 5.2 rad/s`, `BiteDamage = 2` HP every `0.70s` after a `0.45s` grace period).
- **Double-Volume Flight & Gallant Ocean Rescues:** When teeth strike, unbitten companions scramble ashore shrieking `SCARED -> PAPA` at **twice customary volume** (`FleeYellVolumeMultiplier = 2.0`), while each unbitten swimmer retains a **5% chance** (`HeroShark.TriggerChance = 0.05`) to cry her complete, unclipped battle-pledge — **`"I WILL SAVE YOU SISTER!"`** — moments before a jaw-snapping **Hero Shark** drags her cleanly into the abyss.
- **Crimson Waters:** Injuries paint expanding **blood slicks** across the surface (`2.6m` initial, `7.2m` maximum radius, `34.0s` dissipation) and imbue submerged vision with an alarming scarlet fog (`UnderwaterTintEnabled = true`, toggleable at will via Blood ON/OFF inside `[M]`).

### 2. Soup Bowl Athletics (`G`) & *La Chancla* Tool Slot
- **The Indignant Soup Flip (`G`):** Whilst bearing a brimming bowl of hot soup, press **`G`** (`BowlSpillKey`) to execute a brisk, fluent procedural wrist-flick — tipping the vessel downward (`~160°`) to cast its broth cleanly upon the ground (`BowlStateController`), scattering droplets, staining a fleeting puddle with splash acoustics, and prompting every sister within `2.0m` to utter horrified disapproval (`DISAPPROVE_2_STANDING`). Holding an empty bowl and pressing **`G`** hurls it forthwith at maximum force.
- **Aerial Bowl Rebukes:** Striking a pup cleanly with a thrown bowl delivers a sharp Zoomies-style burst without knock-out or knockdown, snapping her upright (`STARTLE`) with a crestfallen scared grimace devoid of cheer.
- **La Chancla (Custom Tool Slot — Immediately Before Mallet):** Scroll your tool wheel right before the Mallet to wield **La Chancla** cleanly by its heel base at a crisp diagonal angle matching its custom `64x64` icon, free of recovery popups on load. Left-clicking launches the spinning slipper along your crosshair (`1.8s` ground dwell after bounce):
  - **Chivalrous Ground Intangibility:** Pups already knocked out, slumbering, tumbling, or lying/rising on the ground remain wholly **intangible** to the slipper's flight until safely back upon their feet.
  - **Jovial Zoomies Pop:** Striking an upright pup triggers original Zoomies collision bursts (`vfxBurstSpawner`, `HIT_BY_PROJECTILE_FRONT`/`BACK`), cheerful giggles, a playful hop without injury, and a delighted expression.

### 3. Compact Iron Pup Containment (`PUP CAGE`, `1` Log)
- **Unlocked from Day One:** Construct the cramped iron **`PUP CAGE`** (`0.56m × 0.56m × 0.78m`, forged strictly without unsightly pet water-bottles) anywhere upon the turf for **1 Log**.
- **Frantic Bar-Rattling Custody (`E`) & Overhead Nameplate:** Aim within `4.0m` and press **`E`**, or drop/toss a carried pup past the open gate, to slam the padlocked door shut (`720°/s`). Inside, the detainee keeps her authentic **visible nameplate overhead** (`GATNames` + `FakeGATManager`), gazes straight forth with wide panicked eyes and chattering teeth, shivers continuously at `14–18 Hz`, and grips both front iron bars during periodic frantic bar-rattling bursts synced physically to the trembling cage until released anew with **`E`**. Persists reliably across saves and Quicksaves.

### 4. Bamboo Cage Hostage (`BAMBOO CAGE`, `1` Log), Retaliation & Cauldron Alchemy
- **The Gaoler's Safeguard (`E` within `3.2m`):** Unlocked from the outset for **1 Log**. Present **Wolf Mama** and press **`E`** to bolt her indoors in `standing_scare` with blazing red eyes — halting dawn rage points, punishment dreams, and Game Over triggers whilst imprisoned.
- **The Gaoler's Reckoning:** Should any pup perish while Wolf Mama languishes behind bamboo bars, **unlocking that gate with `E` unleashes her lethal ambush upon the spot**. Cages, ponds, and retaliation flags endure reliably across standard saves and Quicksaves.
- **Wolf Mama's Spiral-Eyed Cauldron Ritual (100 Chicken Drumsticks):** Whenever a pup corpse rests within `10m` of uncaged Wolf Mama, she approaches, adopts dizzying **spiral eyes** with a bewildered `"woah"`, cradles the fallen child with `pup_carry_auto_grab`, and marches straight to the nearest lit, watered, meatless cauldron — depositing the remains for **100 chicken drumsticks equivalent** (matching player-tossed cauldron corpses).

### 5. Campfire Ignition, 10s Scream/Zoomies Alternation, 60s Dying Crawl & Water Salvation
- Leaving a pup over a blazing **campfire** sets her ablaze once the vanilla hop concludes (`PupFireManager`), dashing frantically within `15m` of Father and alternating every `10s` between panicked screaming (`STARTLE`) and manic zoomies (`RUN_FRENZY` + `long wee`).
- Bumping another pup carries a **50% chance** to spread the blaze (after `45s` without contact, burning pups actively seek a sister). After **`60s`** (transitioning cleanly into `morente`), the pup collapses into a **non-lethal Dying crawl** without arousing Wolf Mama's wrath — lying belly-down facing forward, smoking, and creeping slowly toward the nearest natural river or Sacrificial Pond, where water restores her completely.

### 6. Towering `SACRIFICIAL POND` (`1` Log), `MINING` Boulder (`1` Boulder) & Coiffure Overhaul
- **`SACRIFICIAL POND` (`1` Log):** Raises a clear basin beneath a `3.55m` diving ladder and springboard (`[E] Sacrifice a Pup to the Piranha GOD`). Aim and press **`E`** to dub **`THE CHOSEN ONE`**, gathering up to **100** chanting spectators before she plunges into a 100% piranha frenzy, summons a **Chicken Drumstick sky rain**, and leaves a pup-haired Skeleton tossed by two acolytes until dismissed by `E` or `F`.
- **`MINING` Ore Boulder (`1` Boulder):** Assign up to **4** pups via **`E`** outfitted in illuminated miner helmets and pickaxes, striking ore amidst metallic clangs and sparks every `1.25s`.
- **Hairbrush & Hairstyles Unlocked:** The **Hairbrush** blueprint costs but **1 Fresh Grass bundle** (`ConstructionMaterial.GRASS`) and **every hairstyle is unlocked immediately**.

### 7. Sky, Beast, Boulder & Divine Hotkeys (`V`, `B`, `Z`, `T`)
- **`V` — Vulture or Stork Delivery (selectable in `[M]`):**
  - *Vulture Mode:* A circling raptor screeches, swoops down, and abducts a pup skyward.
  - *Stork Mode:* A noble black-and-white Stork glides overhead bearing a newborn pup inside a knotted cloth bundle (*"fagottino"*), releasing it wherever your gaze is aimed to deliver a brand-new sister upon touchdown.
- **`B` — Angry Boar (`MaxHealth = 12`):** Summons a charging wild Boar that impales a random pup alive upon its left tusk; defeat it by launching pups airborne (`0` pup damage, `1 HP` Boar damage each).
- **`Z` — Zeus Intervention (3 modes in `[M]`):** Strikes a random living pup **without provoking Wolf Mama's wrath**, cycling between **`[Z] lightning bolt`**, **`[Z] heavenly wrath`** (sacred golden beam + celestial choir), and **`[Z] boulder`** (hurls a skyward boulder crushing pups cleanly into **3 chicken drumsticks**, matching hanging/falling boulder trap physics without blood, skulls, or gore).
- **`T` — 3-Pup Totem Stacks:** Assembles free pups into wobbly 3-tier vertical totems obeying **`F`** commands via the bottom pup; press **`T`** again to dismount.

### 8. Grand Salons (`M`, `N`, `O`), Neglect Deaths, Gravestones & Sprint Knockback
- **`M` (Pup State Salon):** Trigger **`hungry`**, **`thirsty`**, **`sick (vomit)`**, **`dead (corpse)`** (non-wrathful), **`morente (dying crawl)`**, **`starvation (global)`** (hungry-only **Evening** Runt chase), **`rebellion`**, **`zoomies light`** (native AI + `E`/`F` intact, `RUN_FRENZY` + `LongWee`, zero collisions), **`zoomies plus`** (6m local roam & bush-hiding around stationary Father with gentle collisions), **`ZOOMIES (global)`** (vanilla PokeFrenzy), **`boar rider`** (real Boars obeying **`[F]`** only, 80% saddle / 20% comical head-peek), **`[Z]`**, **`[V]`**, **`blood: ON/OFF`**, and **`cure & feed`**.
- **`N` (Pup & Wolf Mama Studio):** Full Episode 4 pup animation/face/sound library (`sounds`, `9:16` Shorts reticle) plus a dedicated **Wolf Mama** tab (animations, eyes, pupils, mouth phonemes, voice lines, and audio clips).
- **`O` (Spawn Menu — `Actors`, `Books` & `Tools`):**
  - **`Actors`:** Spawn the rope-bound, struggling **Angry Old Man** villager (procedural rig or custom `.glb`/`.obj` from `BepInEx\plugins\RedMenaceRevenge\Assets\`, hot-reloadable; lifted by hand or hauled by **4 pups via `E`**).
  - **`Books`:** Browse and spawn every readable `LoreContent` volume in the realm.
  - **`Tools`:** Spawn bouncing **Cracked Pup Skulls** for **Skull Soccer** (2 random pups chase and pass continuously, or aim + `E` to rally players, yielding dutifully to `E`/`F`).
- **Dawn Neglect (`BeginNewDay`), Gravestones, Chatter, `Gremlins` HUD & 0% Sprint Dodge:** Unfed/unwatered pups perish at dawn into `X X`-eyed ragdoll corpses (`5.0m` mourning radius; bury with `LMB`/`E` beneath wooden headstones); pups eagerly name nearby held animals; left-side HUD greets your charges as **`Gremlins`**; and **holding `Left Shift` to sprint reduces pup dodge chance from `90%` to `0%`**, sending pups tumbling cleanly without damage.

### 9. Concerning Certain Salacious Village Rumours
- Pay no heed whatever to breathless whispers circulating round the village well regarding an alleged cast-iron "Meat Grinder" contraption turning mishaps into chicken drumsticks. Upon the solemn honour of a Victorian gentleman, this author declares all such culinary gossip to be pure moonshine, vulgar fiddle-faddle, and an impudent scoundrel's jest!

---

## Requirements

- **Family Time Episode 4** (Windows Mono — root `FamilyTime.exe` directory, no `DX11` subfolder)
- **BepInEx 5** (`BepInEx 5.4.23.5` or compatible BepInEx 5.x for Unity Mono; `0Harmony.dll` included)

---

## Save Compatibility & Custom External Assets

- Custom blueprints (`BAMBOO CAGE`, `PUP CAGE`, `SACRIFICIAL POND`, `MINING`), caged occupants, cage retaliation flags, gravestones, and permanent pup corpses persist cleanly across standard saves and Quicksaves inside an adjacent `<SaveFile>.family.redmenace.dat` sidecar file, leaving base `.family` save files untouched.
- Optional custom `.glb` / `.obj` villager models and sibling textures can be placed in `<GameDir>\BepInEx\plugins\RedMenaceRevenge\Assets\` and hot-reloaded in-game from the **`[O]` Spawn Menu**.

---

## Installation

1. Verify **BepInEx 5** is installed in your *Family Time Episode 4* root folder (`FamilyTime.exe` directory).
2. Extract **`PiranhaTime2TheRevenge-v1.2.0.zip`** directly into that game folder so the DLL lands at:
   ```text
   <GameDir>\BepInEx\plugins\RedMenaceRevenge\RedMenaceRevenge.dll
   ```
3. Launch the game once to generate:
   ```text
   <GameDir>\BepInEx\config\com.redmenacerevenge.hazards.cfg
   ```

---

## Building from Source

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```
