# Piranha Time 2: The Revenge (v1.1.0)

**A BepInEx 5 gameplay, hazard & chaos mod for *Family Time Episode 4*.**

*Nature is cruel, unpredictable, and indifferent.* **Piranha Time 2: The Revenge** (`RedMenaceRevenge.dll`) brings the full wilderness survival suite to *Family Time Episode 4* and pushes the madness further — combining deep-water Follow swimming, 5% river piranha swarms and Hero Shark ambushes, bloodied water, dawn neglect fatalities with `X X`-eyed ragdoll corpses & burial gravestones, a persistent **Bamboo Cage** hostage & retaliation system, the tall **Sacrificial Pond** (`THE CHOSEN ONE`), the **`MINING`** boulder blueprint, sky-snatching **Vultures** (`V`), charging **Angry Boars** (`B`), **Zeus / Heavenly Wrath** strikes (`Z`), on-demand **3-Pup Totem Stacks** (`T`), hungry-only **Evening Starvation** & **Rebellion** events (`M`), **Campfire Ignition -> 60s Dying Crawl -> Water Healing**, **Wolf Mama Spiral-Eyed Corpse Cauldron Delivery (100 Chicken Drumsticks)**, boosted **Animal Chatter**, **1-Grass Hairbrush + All Hairstyles Unlocked**, and an expanded **Pup & Wolf Mama Studio (`N`)**.

---

## Features

### 1. Deep-Water Follow Swimming, River Piranhas (`5%`), Pack Flight, Hero Shark & Blood Water
- **Water Follow Pathfinding Fix:** Commanding Follow (`F`) while standing or swimming in deep water routes pups cleanly off riverbanks and shorelines to swim straight out to you.
- Pups wading (`>= 0.08m`) or swimming in water roll a **5% chance** on water entry (and every `30s` thereafter, `AttackRollIntervalSeconds = 30.0`, `AttackRollChance = 0.05`) to attract aggressive **circling piranha swarms** (`MaxPiranhasPerPup = 8`, `TotalMaxPiranhas = 96`, `OrbitSpeed = 5.2 rad/s`, `BiteDamage = 2` HP every `0.70s`).
- During an attack, unattacked pups flee ashore screaming `SCARED` -> `PAPA` at **double volume** (`FleeYellVolumeMultiplier = 2.0`), and each unattacked pup has a **5% chance** (`HeroShark.TriggerChance = 0.05`) to cry **`"I WILL SAVE YOU SISTER!"`** before a **Hero Shark** drags her down into the depths.
- Injuries spread **crimson blood slicks** (`2.6m` initial, `7.2m` max radius, `34.0s` fade) and tint underwater fog red (`UnderwaterTintEnabled`).

### 2. Campfire Ignition, 10s Scream/Zoomies Alternation, 60s Dying Crawl & Water Cure
- Leaving a pup over a **campfire** ignites her when the vanilla campfire bounce finishes:
  - Runs wildly within **`15m`** of Dad, alternating every **`10s`** between panicked screaming (`STARTLE`) and zoomies (`RUN_FRENZY` with `long wee3` / `long wee7`).
  - Bumping another pup has a **50% chance** to ignite her too (after `45s` without hitting another pup, burning pups actively aim toward the nearest sister).
  - After **`60s`** on fire, burning pups collapse into a **non-lethal Dying (`morente`) state** without triggering Wolf Mama's wrath: they lie belly-down facing forward, smoking and permanently scared, slowly crawling toward the nearest pond or river.
  - **Water Healing:** Reaching real water (natural water or a Sacrificial Pond) extinguishes and heals a burning or dying pup back to normal!

### 3. Wolf Mama Spiral-Eyed Corpse Ritual & 100-Drumstick Cauldron Stew
- Whenever a pup corpse lies within **`10m`** of **Wolf Mama**, she walks over, switches to **spiral eyes**, gives a single confused `"woah"`, performs **`pup_carry_auto_grab`**, holds the corpse for **`3s`**, repeats **`pup_carry_auto_grab`**, and then walks to the first **lit, watered, meatless cauldron** to drop the corpse in for **100 chicken drumsticks equivalent**.
- Any pup corpse thrown or dropped into a watered cauldron by the player also yields **100 chicken drumsticks equivalent**.

### 4. Bamboo Cage Hostage (`BAMBOO CAGE`), Retaliation & Save Persistence
- Unlocked from the start (**`BAMBOO CAGE`**, costs **1 Log**). Bring **Wolf Mama** within `InteractRadius = 3.2m` and press **`E`** to lock her inside in `standing_scare` with glowing red eyes, blocking rage points, angry sleep movies, and Game Over triggers while imprisoned.
- **Cage Retaliation:** If any pup dies while Wolf Mama is imprisoned, **reopening the cage with `E` immediately unleashes Wolf Mama to kill the player**. Cages, ponds, and retaliation state persist across normal saves and Quicksaves.

### 5. `SACRIFICIAL POND` Blueprint (`1` Log) & `MINING` Blueprint (`1` Boulder)
- **`SACRIFICIAL POND` (1 Log):** Places a piranha basin beneath a `3.55m` diving ladder and springboard (`[E] Sacrifice a Pup to the Piranha GOD`). Aim and press **`E`** to dub **`THE CHOSEN ONE`**, gathering up to **100** spectators looping `want 2` before she dives into a 100% piranha frenzy, triggers a **Chicken Drumstick sky rain**, and leaves a pup-haired skeleton tossed by 2 acolytes until dismissed by `E` or `F`.
- **`MINING` (1 Boulder):** Assign up to **4** pups (`E`) to equip glowing miner helmets and pickaxes, swinging at the ore boulder with metallic strikes and sparks.

### 6. Sky, Beast & Divine Hotkey Hazards (`V`, `B`, `Z`) & 3-Pup Totem Stacks (`T`)
- **`V` (Vulture):** Summons a circling vulture that swoops down and carries a pup away into the sky.
- **`B` (Angry Boar):** Summons an Angry Boar (`BoarMaxHealth = 12`) that impales a random pup alive on its left tusk; slay it by launching pups airborne (`0` pup damage, `1 HP` Boar damage each).
- **`Z` (Zeus Intervention):** Strikes a random living pup from above leaving a smoking corpse **without triggering Wolf Mama's wrath**. Switch in **`M`** between **`[Z] lightning bolt`** and **`[Z] heavenly wrath`**.
- **`T` (3-Pup Totem Stacks):** Groups unoccupied pups into wobbly 3-tier vertical totems obeying **`F`** commands via the bottom pup; press **`T`** again for a 2-step dismount.

### 7. Neglect Deaths, `X X` Corpses, Gravestones, Animal Chatter & Hairbrush Overhaul
- At dawn (`BeginNewDay`), genuinely neglected pups die into physics-settled ragdoll corpses with **`X X`** eyes (`5.0m` mourning radius); bury them with **`LMB`** / **`E`** beneath persistent wooden **gravestones**.
- **Chatty Animal Reactions:** Greatly boosted the chance for pups to speak and try naming animals when you hold an animal near them.
- **Hairbrush & Hairstyles:** The **Hairbrush** blueprint costs **1 Fresh Grass bundle (`ConstructionMaterial.GRASS`)** and **all hairstyles are unlocked immediately**.

### 8. Pup State Panel (`M`) & Pup / Wolf Mama Studio (`N`)
- **`M` (State Panel):** Trigger **`hungry`**, **`thirsty`**, **`sick (vomit)`**, **`dead (corpse)`** (without triggering Wolf Mama wrath), **`morente (dying crawl)`**, **`starvation (global)`** (hungry-only Runt chase, also auto-triggered at `Evening`), **`rebellion`**, **`cure & feed`** (also cures burning/dying pups), and **`[Z]`** Zeus mode toggle.
- **`N` (Animation & Audio Studio):** Updated with Episode 4 pup actions, faces, and sounds (clapping, zoomies, bed jumps, animal words) plus a dedicated **Wolf Mama** tab (animations, eyes, pupils, mouth phonemes, voice lines, and audio clips), `loop: ON/OFF`, `yt shorts 9:16` framing lines, and `reset idle`.
- **90% Dad Dodge Roll:** Sprinting through pups rolls a 90% nimble step-back vs. 10% zero-damage tumble.

### 9. Concerning Preposterous Rumours
- Pay no mind to idle whispers in the village concerning an alleged "Meat Grinder" apparatus: I assure you upon the honour of a Victorian gentleman that such lurid gossip is sheer moonshine and tomfoolery.

---

## Requirements

- **Family Time Episode 4** (Windows Mono — root `FamilyTime.exe` directory, no `DX11` subfolder)
- **BepInEx 5** (`BepInEx 5.4.23.5` or compatible BepInEx 5.x for Unity Mono)

---

## Save Compatibility

- Custom blueprints, caged Wolf Mama / retaliation flags, gravestones, and permanent pup corpses are stored in an adjacent `<SaveFile>.family.redmenace.dat` sidecar file and survive standard saves and Quicksaves. Base `.family` save files remain vanilla-compatible.

---

## Installation

1. Install **BepInEx 5** into your *Family Time Episode 4* game folder (`FamilyTime.exe` root directory) if not already installed.
2. Extract `PiranhaTime2TheRevenge-v1.1.0.zip` into that game folder so the DLL lands at:
   ```text
   <GameDir>\BepInEx\plugins\RedMenaceRevenge\RedMenaceRevenge.dll
   ```
3. Launch the game once. BepInEx will generate your config at:
   ```text
   <GameDir>\BepInEx\config\com.redmenacerevenge.hazards.cfg
   ```

---

## Building from Source

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```
