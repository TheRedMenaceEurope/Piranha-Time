# Changelog — Piranha Time 2: The Revenge

## v1.1 (1.1.0)
- **Ported Full Hazard & Survival Suite to *Family Time Episode 4*:**
  - Deep-water Follow (`F`) pathfinding fix (`NavWaterFollowPatch`), 5% river piranha swarms, 5% unclipped Hero Shark (`"I WILL SAVE YOU SISTER!"`), blood slicks & red underwater fog tint.
  - Dawn neglect fatalities (`X X`-eyed ragdoll corpses & burial gravestones), persistent **Bamboo Cage** hostage & retaliation, **`SACRIFICIAL POND`** (`THE CHOSEN ONE` + drumstick rain), **`MINING`** boulder, **Vulture** (`V`), **Angry Boar** (`B`), **Zeus / Heavenly Wrath** (`Z`), **3-Pup Totem Stacks** (`T`), hungry-only **Evening Starvation Runt** & **Rebellion** (`M`), and **90% Dad Dodge Roll**.
- **Campfire Fire-Panic, 60s Dying Crawl & Water Cure (`PupFireManager`):**
  - Pups left on a campfire ignite after the vanilla hop animation, spread fire to 50% of bumped sisters (auto-targeting the nearest pup after 45s), stay within `15m` of Dad, and alternate every `10s` between panicked screaming and zoomies (`RUN_FRENZY` + `long wee3` / `long wee7`).
  - After **`60s`** on fire, pups enter a **non-lethal Dying (`morente`) state** without triggering Wolf Mama's wrath, crawling belly-down facing forward toward the nearest water and returning cleanly to normal upon reaching water.
- **Wolf Mama Spiral-Eyed Corpse Cauldron Ritual (`WolfMamaCorpseCauldronManager`):**
  - Wolf Mama approaches corpses within `10m` with synced locomotion animation, switches to spiral eyes with a single `"woah"`, performs a single `pup_carry_auto_grab`, and deposits the corpse into the first lit, watered, meatless cauldron for **100 chicken drumsticks equivalent** (matching player-thrown cauldron corpses).
- **Episode 4 Studio (`N`), State Panel (`M`), Animal Chatter & Hairbrush Unlock:**
  - Updated **`N`** studio with Episode 4 animations, faces, and sounds (clapping, zoomies, bed jumps, animal words) plus a dedicated **Wolf Mama** tab with working mouth phonemes.
  - Updated **`M`** state panel with **`morente (dying crawl)`**, non-wrathful `dead (corpse)`, **`zoomies light`**, **`zoomies plus`** (6m roam & hiding around Dad with collisions without exiting), **`ZOOMIES (global)`**, **`boar rider`** (real Boars obeying **`[F]`** only), **`[Z]`** mode switcher (**Lightning / Wrath / Boulder**), **`[V]`** mode switcher (**Vulture / Stork** pup delivery), **`blood: ON/OFF`** toggle, and full cleanup in `cure & feed`.
  - Boosted pup animal-naming chatter when holding an animal nearby (`AnimalChatterManager`).
  - Set the **Hairbrush** blueprint cost to **1 Fresh Grass bundle (`ConstructionMaterial.GRASS`)** and unlocked all hairstyles immediately (`HairstyleService.IsUnlocked`).
  - **Boulder Trap & `[Z]` Falling Boulder Pup Crushing (`BoulderController`):** Hanging/falling boulder traps and **`[Z] boulder`** crush pups cleanly into **3 chicken drumsticks** (no whole corpse, blood, skulls, or gore).
  - **Spawn Menu (`O`) with `Actors`, `Books` & `Tools` (`SpawnMenuPanel`, `CaptiveOldManManager`, `AngryOldManVisualFactory`, `CrackedSkullBallManager`):**
    - **`Actors`**: Spawn the bound, struggling Angry Old Man with hand-painted comic portrait (4 pups lift and haul him via **`E`** like boulders and logs, plus `.glb`/`.obj` external asset support in `BepInEx\plugins\RedMenaceRevenge\Assets\`).
    - **`Books`**: Browse and spawn every readable `LoreContent` book in the game.
    - **`Tools`**: Spawn the **Cracked Pup Skull** for **Skull Soccer** (2 random pups chase and pass it 3.2m apart crying `wahoo`/`yahoo`, yielding immediately to **`E`** or **`F`** commands).
